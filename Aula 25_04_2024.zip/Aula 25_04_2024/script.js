document.getElementById("cadastroForm").addEventListener("submit", function(event){ 
    
    event.preventDefault();
    
    var id = document.getElementById("id").value;
    var nome = document.getElementById("nome").value;
    var telefone = document.getElementById("telefone").value;

    var cadTelefone = {
        id: id,
        nome: nome,
        telefone: telefone
    }
    
    console.log(cadTelefone);

    if(sessionStorage.getItem("telefones")){
        var telefoneList = JSON.parse(sessionStorage.getItem("telefones"))
        telefoneList.push(cadTelefone);
        sessionStorage.setItem("telefones", JSON.stringify(telefoneList)) 
    }else{
        var novaLista = [cadTelefone]
        sessionStorage.setItem("telefones", JSON.stringify(novaLista));
    }

    document.getElementById("cadastroForm").reset();

});